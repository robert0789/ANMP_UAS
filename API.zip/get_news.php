<?php
include("koneksi.php");
error_reporting(E_ERROR | E_PARSE);

try {
    // Koneksi ke database MySQL
if ($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}

// Melakukan query untuk mencocokkan username dan password dalam database
$sql = "SELECT news.id, news.title, users.username, news.description,news.image_url ,news.date  FROM news
INNER JOIN users on news.user_id = users.id";
$stmt = $conn->prepare($sql);

$arr_news = array();
if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_object()){
            $arr_news[] = $row;
        }
        // Data ditemukan, autentikasi berhasil
        echo json_encode(array('result' => 'OK', 'data'=> $arr_news));
    } else {
        // Data tidak ditemukan, autentikasi gagal
        echo json_encode(array('result' => 'ERROR', 'message' => 'Invalid username or password'));
    }
} else {
    // Error in executing the query
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to execute query'));
}
} catch (\Throwable $th) {
    echo json_encode(array('result'=>'ERROR', 'message'=>$th));
}

?>
