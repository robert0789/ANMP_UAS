<?php
include("koneksi.php");
error_reporting(E_ERROR | E_PARSE);

try {
    // Koneksi ke database MySQL
if ($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}

// Mengambil data dari permintaan POST
$userID = $_GET['id'];

// Melakukan query untuk mencocokkan username dan password dalam database
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);

$stmt->bind_param("i", $userID);
$data = null;

if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $data = $result->fetch_object();
        // Data ditemukan, autentikasi berhasil
        echo json_encode(array('result' => 'OK', 'data'=> $data));
    } else {
        // Data tidak ditemukan, autentikasi gagal
        echo json_encode(array('result' => 'ERROR', 'message' => 'Invalid user ID'));
    }
} else {
    // Error in executing the query
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to execute query'));
}
} catch (\Throwable $th) {
    echo json_encode(array('result'=>'ERROR', 'message'=>$th));
}

?>
