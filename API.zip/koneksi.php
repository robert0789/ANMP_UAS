<?php
$conn = new mysqli("localhost", "root" ,"","anmp_news");
  

