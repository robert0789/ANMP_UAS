<?php
include("koneksi.php");
error_reporting(E_ERROR | E_PARSE);

try {
    // Koneksi ke database MySQL
if ($conn->connect_errno) {
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
    die();
}

// Mengambil data dari permintaan POST
$userID = $_POST['id'];
$firstName = $_POST['first_name'];
$lastName = $_POST['last_name'];


// Melakukan query untuk mencocokkan username dan password dalam database
$sql = "UPDATE users SET first_name = ?, last_name=?  WHERE id = ?";
$stmt = $conn->prepare($sql);

$stmt->bind_param("ssi", $firstName,$lastName, $userID);
$data = null;

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userID);

        if($stmt->execute()){
            $result = $stmt->get_result();
            $data = $result->fetch_object();

            echo json_encode(array('result' => 'OK', 'data'=> $data));
        }        
    } else {
        // Data tidak ditemukan, autentikasi gagal
        echo json_encode(array('result' => 'ERROR', 'message' => 'user ID not found'));
    }
} else {
    // Error in executing the query
    echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to execute query'));
}
} catch (\Throwable $th) {
    echo json_encode(array('result'=>'ERROR', 'message'=>$th));
}

?>
