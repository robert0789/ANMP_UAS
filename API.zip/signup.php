<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
include_once("koneksi.php");
error_reporting(E_ERROR | E_PARSE);


try {
    // Koneksi ke database MySQL

    if ($conn->connect_errno) {
        echo json_encode(array('result' => 'ERROR', 'message' => 'Failed to connect DB'));
        die();
    }

    // Mengambil data dari permintaan POST
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $imgUrl = $_POST["img_url"];



    // Melakukan query untuk mencocokkan username dan password dalam database
    $sql = "INSERT INTO users (`username`, `first_name`, `last_name`, `email`, `password`, `image_url`)
VALUE (?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssssss", $username, $firstName, $lastName, $email, $password, $imgUrl);

    if ($stmt->execute()) {
        echo json_encode(array('result' => 'OK', 'message' => 'Signup Successful'));
    } else {
        echo json_encode(array('result' => 'ERROR', 'message' => 'Input data invalid'));
        die();
    }
} catch (\Throwable $th) {
    echo json_encode(array('result' => 'ERROR', 'message' => $th));

}